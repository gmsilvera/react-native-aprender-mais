import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet,SafeAreaView } from 'react-native'
import Start from './screens/Start';
import HomeList from './screens/HomeList';
import Alfabeto from './screens/Alfabeto';
import Vogais from './screens/Vogais';
import Silabas from './screens/Silabas';

const Stack = createNativeStackNavigator();

export default function App() {
  return (

    <NavigationContainer>
      <Stack.Navigator /*screenOptions={{
    headerShown: false
  }}*/ initialRouteName="Home">
        <Stack.Screen options= {{headerShown: false}} name="Start" component={Start}  />
        <Stack.Screen options= {{headerShown: false}} name="HomeList" component={HomeList} />
        <Stack.Screen name="Alfabeto" component={Alfabeto} />
        <Stack.Screen name="Vogais" component={Vogais} />
        <Stack.Screen name="Silabas" component={Silabas} />
      </Stack.Navigator>
    </NavigationContainer>


     
 /*   <NavigationContainer>
      <Stack.Navigator /*screenOptions={{
    headerShown: false
  }} initialRouteName="Home">
        <Stack.Screen name="Alfabeto" component={Alfabeto} />
        <Stack.Screen name="Vogais" component={Vogais} />
        <Stack.Screen name="Silabas" component={Silabas} />
      </Stack.Navigator>
    </NavigationContainer>*/
  );
}