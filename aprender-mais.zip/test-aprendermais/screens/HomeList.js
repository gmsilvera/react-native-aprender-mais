import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  VirtualizedList,
  TouchableOpacity,
} from 'react-native';

const DATA = [
  {
    id: '1',
    title: 'ALFABETO',
    description: 'Aprendendo as letras.',
    image: require('../assets/iconABC.png'),
    screen: 'Alfabeto',
  },
  {
    id: '2',
    title: 'VOGAIS',
    description: 'Conheça quem são as vogais.',
    image: require('../assets/iconAEIOU.png'),
    screen: 'Vogais',
  },
  {
    id: '3',
    title: 'SÍLABAS SIMPLES',
    description: 'Conheça as sílabas simples.',
    image: require('../assets/silabas.png'),
    screen: 'Silabas',
  },
];

const getItem = (data, index) => data[index];

const getItemCount = (data) => data.length;

const Item = ({ title, description, image, screen }) => (
  <View style={styles.item}>
    <Image source={image} style={styles.itemImage} />
    <View style={styles.textContainer}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.description}>{description}</Text>
    </View>
  </View>
);

const HomeList = ({ navigation }) => (
  <View style={styles.container}>
      <Image
        source={require('../assets/logoAprenderMais.png')}
        style={styles.headerImage}
      />
      <Text style={{ textAlign: 'center', fontSize: 20, height: 50 }}>
        Dentro e fora da escola.
      </Text>
    <VirtualizedList
      data={DATA}
      initialNumToRender={3}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => navigation.navigate(item.screen)}>
          <Item
            title={item.title}
            description={item.description}
            image={item.image}
            screen={item.screen}
          />
        </TouchableOpacity>
      )}
      keyExtractor={(item) => item.id}
      getItemCount={getItemCount}
      getItem={getItem}
    />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  // headerContainer: {
  //   alignItems: 'center',
  //   marginVertical: 20,
  // },
  headerImage: {
    width: 300,
    height: 150,
    alignSelf: 'center',
    marginTop: 100,
    marginBottom: 30,
    padding: 50,
  },
  item: {
    flexDirection: 'row',
    padding: 10,
    marginVertical: 8,
    marginHorizontal: 16,
    backgroundColor: '#F2F2F2',
    borderRadius: 10,
  },
  itemImage: {
    width: 80,
    height: 80,
    marginRight: 10,
    borderRadius: 5,
  },
  textContainer: {
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 16,
  },
});

export default HomeList;
