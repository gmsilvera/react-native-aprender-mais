import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  ImageBackground,
  TouchableOpacity,
} from 'react-native';
import { Audio } from 'expo-av';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

function VirtualizedListPage({ navigation }) {
  const DATA = Array.from({ length: 1000 }, (_, i) => `Item ${i + 1}`);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text>{item}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaView>
  );
}

function Alfabeto({ navigation }) {
  const vowels = [
    { label: 'A', sound: require('../assets/alfabeto/a.mp3'), cor: '#ff3131' },
    { label: 'B', sound: require('../assets/alfabeto/b.mp3'), cor: '#ff5757' },
    { label: 'C', sound: require('../assets/alfabeto/c.mp3'), cor: '#ff66c4' },
    { label: 'D', sound: require('../assets/alfabeto/d.mp3'), cor: '#cb6ce6' },
    { label: 'E', sound: require('../assets/alfabeto/e.mp3'), cor: '#8c52ff' },
    { label: 'F', sound: require('../assets/alfabeto/f.mp3'), cor: '#5e17eb' },
    { label: 'G', sound: require('../assets/alfabeto/g.mp3'), cor: '#0097b2' },
    { label: 'H', sound: require('../assets/alfabeto/h.mp3'), cor: '#0cc0df' },
    { label: 'I', sound: require('../assets/alfabeto/i.mp3'), cor: '#5ce1e6' },
    { label: 'J', sound: require('../assets/alfabeto/j.mp3'), cor: '#38b6ff' },
    { label: 'K', sound: require('../assets/alfabeto/k.mp3'), cor: '#5271ff' },
    { label: 'L', sound: require('../assets/alfabeto/l.mp3'), cor: '#004aad' },
    { label: 'M', sound: require('../assets/alfabeto/m.mp3'), cor: '#00bf63' },
    { label: 'N', sound: require('../assets/alfabeto/n.mp3'), cor: '#7ed957' },
    { label: 'O', sound: require('../assets/alfabeto/o.mp3'), cor: '#c1ff72' },
    { label: 'P', sound: require('../assets/alfabeto/p.mp3'), cor: '#ffde59' },
    { label: 'Q', sound: require('../assets/alfabeto/q.mp3'), cor: '#ffbd59' },
    { label: 'R', sound: require('../assets/alfabeto/r.mp3'), cor: '#ff914d' },
    { label: 'S', sound: require('../assets/alfabeto/s.mp3'), cor: '#f3a42c' },
    { label: 'T', sound: require('../assets/alfabeto/t.mp3'), cor: '#c33a29' },
    { label: 'U', sound: require('../assets/alfabeto/u.mp3'), cor: '#0097b2' },
    { label: 'V', sound: require('../assets/alfabeto/v.mp3'), cor: '#073B4C' },
    { label: 'W', sound: require('../assets/alfabeto/w.mp3'), cor: '#43291f' },
    { label: 'X', sound: require('../assets/alfabeto/x.mp3'), cor: '#4361EE' },
    { label: 'Y', sound: require('../assets/alfabeto/y.mp3'), cor: '#a31621' },
    { label: 'Z', sound: require('../assets/alfabeto/z.mp3'), cor: '#4895EF' },
  ];

  const playSound = async (sound) => {
    const { sound: playbackObject } = await Audio.Sound.createAsync(sound);
    await playbackObject.playAsync();
  };

  return (
    // <ImageBackground
    //   source={require('../assets/alfabeto/fundo.jpg')}
    //   resizeMode="cover"
    //   style={{ width: '100%', height: '100%', flex: 1 }}>
      <View style={styles.container}>
        <View style={styles.gridContainer}>
          {vowels.map((vowel, index) => (
            <View key={vowel.label} style={styles.gridItem}>
              <TouchableOpacity
                onPress={() => playSound(vowel.sound)}
                style={[styles.item, { backgroundColor: vowel.cor }]}>
                <Text style={styles.text}>{vowel.label}</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </View>
    // </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  gridItem: {
    margin: 10,
    height: 65,
    width: 65,
  },
  item: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
    margin: 5,
    borderRadius: 10,
    backgroundColor: '#3D405B',
  },
  text: {
    fontFamily: 'mrt-lili',
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 35,
    lineHeight: 35,
  },
});

export default Alfabeto;
