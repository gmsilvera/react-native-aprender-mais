import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
  Modal,
  Button,
} from 'react-native';
import { Audio } from 'expo-av';
import * as SplashScreen from 'expo-splash-screen';

SplashScreen.preventAutoHideAsync();

function VirtualizedListPage({ navigation }) {
  const DATA = Array.from({ length: 1000 }, (_, i) => `Item ${i + 1}`);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text>{item}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaView>
  );
}

function Silabas() {
  const silab = [
    { label: 'B', sound: require('../assets/alfabeto/b.mp3'), cor: '#ff5757' },
    { label: 'C', sound: require('../assets/alfabeto/c.mp3'), cor: '#ff66c4' },
    { label: 'D', sound: require('../assets/alfabeto/d.mp3'), cor: '#cb6ce6' },
    { label: 'F', sound: require('../assets/alfabeto/f.mp3'), cor: '#5e17eb' },
    { label: 'G', sound: require('../assets/alfabeto/g.mp3'), cor: '#0097b2' },
    { label: 'H', sound: require('../assets/alfabeto/h.mp3'), cor: '#0cc0df' },
    { label: 'J', sound: require('../assets/alfabeto/j.mp3'), cor: '#38b6ff' },
    { label: 'K', sound: require('../assets/alfabeto/k.mp3'), cor: '#5271ff' },
    { label: 'L', sound: require('../assets/alfabeto/l.mp3'), cor: '#004aad' },
    { label: 'M', sound: require('../assets/alfabeto/m.mp3'), cor: '#00bf63' },
    { label: 'N', sound: require('../assets/alfabeto/n.mp3'), cor: '#7ed957' },
    { label: 'P', sound: require('../assets/alfabeto/p.mp3'), cor: '#ffde59' },
    { label: 'Q', sound: require('../assets/alfabeto/q.mp3'), cor: '#ffbd59' },
    { label: 'R', sound: require('../assets/alfabeto/r.mp3'), cor: '#ff914d' },
    { label: 'S', sound: require('../assets/alfabeto/s.mp3'), cor: '#f3a42c' },
    { label: 'T', sound: require('../assets/alfabeto/t.mp3'), cor: '#c33a29' },
    { label: 'V', sound: require('../assets/alfabeto/v.mp3'), cor: '#073B4C' },
    { label: 'W', sound: require('../assets/alfabeto/w.mp3'), cor: '#43291f' },
    { label: 'X', sound: require('../assets/alfabeto/x.mp3'), cor: '#4361EE' },
    { label: 'Z', sound: require('../assets/alfabeto/z.mp3'), cor: '#4895EF' },
  ];

  const Silabas_popup = {
    B: [
      {label: 'BA', sound: require('../assets/silabas/b_a.mp3'), cor: '#ff5757' },
      {label: 'BE', sound: require('../assets/silabas/b_e.mp3'), cor: '#ff66c4' },
      {label: 'BI', sound: require('../assets/silabas/b_i.mp3'), cor: '#cb6ce6' },
      {label: 'BO', sound: require('../assets/silabas/b_o.mp3'), cor: '#5e17eb' },
      {label: 'BU', sound: require('../assets/silabas/b_u.mp3'), cor: '#0097b2' }
      ],
    C: [
      {label: 'CA', sound: require('../assets/silabas/c_a.mp3'), cor: '#ff5757' },
      {label: 'CE', sound: require('../assets/silabas/c_e.mp3'), cor: '#ff66c4' },
      {label: 'CI', sound: require('../assets/silabas/c_i.mp3'), cor: '#cb6ce6' },
      {label: 'CO', sound: require('../assets/silabas/c_o.mp3'), cor: '#5e17eb' },
      {label: 'CU', sound: require('../assets/silabas/c_u.mp3'), cor: '#0097b2' }
      ],
    D: [
      {label: 'DA', sound: require('../assets/silabas/d_a.mp3'), cor: '#ff5757' },
      {label: 'DE', sound: require('../assets/silabas/d_e.mp3'), cor: '#ff66c4' },
      {label: 'DI', sound: require('../assets/silabas/d_i.mp3'), cor: '#cb6ce6' },
      {label: 'DO', sound: require('../assets/silabas/d_o.mp3'), cor: '#5e17eb' },
      {label: 'DU', sound: require('../assets/silabas/d_u.mp3'), cor: '#0097b2' },
      ],
    F: [
      {label: 'FA', sound: require('../assets/silabas/f_a.mp3'), cor: '#ff5757' },
      {label: 'FE', sound: require('../assets/silabas/f_e.mp3'), cor: '#ff66c4' },
      {label: 'FI', sound: require('../assets/silabas/f_i.mp3'), cor: '#cb6ce6' },
      {label: 'FO', sound: require('../assets/silabas/f_o.mp3'), cor: '#5e17eb' },
      {label: 'FU', sound: require('../assets/silabas/f_u.mp3'), cor: '#0097b2' },
      ],
    G: [
      {label: 'GA', sound: require('../assets/silabas/g_a.mp3'), cor: '#ff5757' },
      {label: 'GE', sound: require('../assets/silabas/g_e.mp3'), cor: '#ff66c4' },
      {label: 'GI', sound: require('../assets/silabas/g_i.mp3'), cor: '#cb6ce6' },
      {label: 'GO', sound: require('../assets/silabas/g_o.mp3'), cor: '#5e17eb' },
      {label: 'GU', sound: require('../assets/silabas/g_u.mp3'), cor: '#0097b2' },
      ],
    H: [
      {label: 'HA', sound: require('../assets/silabas/h_a.mp3'), cor: '#ff5757' },
      {label: 'HE', sound: require('../assets/silabas/h_e.mp3'), cor: '#ff66c4' },
      {label: 'HI', sound: require('../assets/silabas/h_i.mp3'), cor: '#cb6ce6' },
      {label: 'HO', sound: require('../assets/silabas/h_o.mp3'), cor: '#5e17eb' },
      {label: 'HU', sound: require('../assets/silabas/h_u.mp3'), cor: '#0097b2' },
      ],
    J: [
      {label: 'JA', sound: require('../assets/silabas/j_a.mp3'), cor: '#ff5757' },
      {label: 'JE', sound: require('../assets/silabas/j_e.mp3'), cor: '#ff66c4' },
      {label: 'JI', sound: require('../assets/silabas/j_i.mp3'), cor: '#cb6ce6' },
      {label: 'JO', sound: require('../assets/silabas/j_o.mp3'), cor: '#5e17eb' },
      {label: 'JU', sound: require('../assets/silabas/j_u.mp3'), cor: '#0097b2' },
      ],
    K: [
      {label: 'KA', sound: require('../assets/silabas/k_a.mp3'), cor: '#ff5757' },
      {label: 'KE', sound: require('../assets/silabas/k_e.mp3'), cor: '#ff66c4' },
      {label: 'KI', sound: require('../assets/silabas/k_i.mp3'), cor: '#cb6ce6' },
      {label: 'KO', sound: require('../assets/silabas/k_o.mp3'), cor: '#5e17eb' },
      {label: 'KU', sound: require('../assets/silabas/k_u.mp3'), cor: '#0097b2' },
      ],
    L: [
      {label: 'LA', sound: require('../assets/silabas/l_a.mp3'), cor: '#ff5757' },
      {label: 'LE', sound: require('../assets/silabas/l_e.mp3'), cor: '#ff66c4' },
      {label: 'LI', sound: require('../assets/silabas/l_i.mp3'), cor: '#cb6ce6' },
      {label: 'LO', sound: require('../assets/silabas/l_o.mp3'), cor: '#5e17eb' },
      {label: 'LU', sound: require('../assets/silabas/l_u.mp3'), cor: '#0097b2' },
      ],
    M: [
      {label: 'MA', sound: require('../assets/silabas/m_a.mp3'), cor: '#ff5757' },
      {label: 'ME', sound: require('../assets/silabas/m_e.mp3'), cor: '#ff66c4' },
      {label: 'MI', sound: require('../assets/silabas/m_i.mp3'), cor: '#cb6ce6' },
      {label: 'MO', sound: require('../assets/silabas/m_o.mp3'), cor: '#5e17eb' },
      {label: 'MU', sound: require('../assets/silabas/m_u.mp3'), cor: '#0097b2' },
      ],
    N: [
      {label: 'NA', sound: require('../assets/silabas/n_a.mp3'), cor: '#ff5757' },
      {label: 'NE', sound: require('../assets/silabas/n_e.mp3'), cor: '#ff66c4' },
      {label: 'NI', sound: require('../assets/silabas/n_i.mp3'), cor: '#cb6ce6' },
      {label: 'NO', sound: require('../assets/silabas/n_o.mp3'), cor: '#5e17eb' },
      {label: 'NU', sound: require('../assets/silabas/n_u.mp3'), cor: '#0097b2' },
    ],
    P: [
      {label: 'PA', sound: require('../assets/silabas/p_a.mp3'), cor: '#ff5757' },
      {label: 'PE', sound: require('../assets/silabas/p_e.mp3'), cor: '#ff66c4' },
      {label: 'PI', sound: require('../assets/silabas/p_i.mp3'), cor: '#cb6ce6' },
      {label: 'PO', sound: require('../assets/silabas/p_o.mp3'), cor: '#5e17eb' },
      {label: 'PU', sound: require('../assets/silabas/p_u.mp3'), cor: '#0097b2' },
    ],
    Q: [
      {label: 'QUA', sound: require('../assets/silabas/q_a.mp3'), cor: '#ff5757' },
      {label: 'QUE', sound: require('../assets/silabas/q_e.mp3'), cor: '#ff66c4' },
      {label: 'QUI', sound: require('../assets/silabas/q_i.mp3'), cor: '#cb6ce6' },
      {label: 'QUO', sound: require('../assets/silabas/q_o.mp3'), cor: '#5e17eb' },
    ],
    R: [
      {label: 'RA', sound: require('../assets/silabas/r_a.mp3'), cor: '#ff5757' },
      {label: 'RE', sound: require('../assets/silabas/r_e.mp3'), cor: '#ff66c4' },
      {label: 'RI', sound: require('../assets/silabas/r_i.mp3'), cor: '#cb6ce6' },
      {label: 'RO', sound: require('../assets/silabas/r_o.mp3'), cor: '#5e17eb' },
      {label: 'RU', sound: require('../assets/silabas/r_u.mp3'), cor: '#0097b2' },
      ],
    S: [
      {label: 'SA', sound: require('../assets/silabas/s_a.mp3'), cor: '#ff5757' },
      {label: 'SE', sound: require('../assets/silabas/s_e.mp3'), cor: '#ff66c4' },
      {label: 'SI', sound: require('../assets/silabas/s_i.mp3'), cor: '#cb6ce6' },
      {label: 'SO', sound: require('../assets/silabas/s_o.mp3'), cor: '#5e17eb' },
      {label: 'SU', sound: require('../assets/silabas/s_u.mp3'), cor: '#0097b2' },
      ],
    T: [
      {label: 'TA', sound: require('../assets/silabas/t_a.mp3'), cor: '#ff5757' },
      {label: 'TE', sound: require('../assets/silabas/t_e.mp3'), cor: '#ff66c4' },
      {label: 'TI', sound: require('../assets/silabas/t_i.mp3'), cor: '#cb6ce6' },
      {label: 'TO', sound: require('../assets/silabas/t_o.mp3'), cor: '#5e17eb' },
      {label: 'TU', sound: require('../assets/silabas/t_u.mp3'), cor: '#0097b2' },
      ],
    V: [
      {label: 'VA', sound: require('../assets/silabas/v_a.mp3'), cor: '#ff5757' },
      {label: 'VE', sound: require('../assets/silabas/v_e.mp3'), cor: '#ff66c4' },
      {label: 'VI', sound: require('../assets/silabas/v_i.mp3'), cor: '#cb6ce6' },
      {label: 'VO', sound: require('../assets/silabas/v_o.mp3'), cor: '#5e17eb' },
      {label: 'VU', sound: require('../assets/silabas/v_u.mp3'), cor: '#0097b2' },
      ],
    X: [
      {label: 'XA', sound: require('../assets/silabas/x_a.mp3'), cor: '#ff5757' },
      {label: 'XE', sound: require('../assets/silabas/x_e.mp3'), cor: '#ff66c4' },
      {label: 'XI', sound: require('../assets/silabas/x_i.mp3'), cor: '#cb6ce6' },
      {label: 'XO', sound: require('../assets/silabas/x_o.mp3'), cor: '#5e17eb' },
      {label: 'XU', sound: require('../assets/silabas/x_u.mp3'), cor: '#0097b2' },
      ],
    Z: [
      {label: 'ZA', sound: require('../assets/silabas/z_a.mp3'), cor: '#ff5757' },
      {label: 'ZE', sound: require('../assets/silabas/z_e.mp3'), cor: '#ff66c4' },
      {label: 'ZI', sound: require('../assets/silabas/z_i.mp3'), cor: '#cb6ce6' },
      {label: 'ZO', sound: require('../assets/silabas/z_o.mp3'), cor: '#5e17eb' },
      {label: 'ZU', sound: require('../assets/silabas/z_u.mp3'), cor: '#0097b2' },
      ],
  };

  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);

  const playSound = async (sound) => {
    const { sound: playbackObject } = await Audio.Sound.createAsync(sound);
    await playbackObject.playAsync();
  };

  const handlePress = (item) => {
    setSelectedItem(item);
    setModalVisible(true);
    playSound(item.sound);
  };

  const handleSilabaPress = (syllable) => {
    playSound(syllable.sound);
  };

  return (
    <View style={styles.container}>
      <View style={styles.gridContainer}>
        {silab.map((sila)=>(
          <View key={sila.label} style={styles.gridItem}>
            <TouchableOpacity
              onPress={() => handlePress(sila)}
              style={[styles.item, {backgroundColor: sila.cor}]}>
              <Text style={styles.text}>{sila.label}</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>

      {selectedItem && (
        <Modal
          transparent={true}
          animationType = 'fade'
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalText}>{selectedItem.label}</Text>
              <View style={styles.silabaContainer}>
                {Silabas_popup[selectedItem.label]?.map((silaba)=>(
                  <TouchableOpacity
                    key={Silabas_popup.label}
                    style={styles.silabaButton}
                    onPress={() => handleSilabaPress(silaba)}>
                    <Text style={styles.silabaText}>{silaba.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Button title="Fechar" onPress={()=>setModalVisible(false)} />
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  gridItem: {
    margin: 10,
    height: 65,
    width: 65,
  },
  item: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
    margin: 5,
    borderRadius: 10,
    backgroundColor: '#3D405B',
  },
  text: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 35,
    lineHeight: 35,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: 300,
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 30,
    marginBottom: 20,
  },
  silabaContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  silabaButton: {
    margin: 5,
    padding: 10,
    backgroundColor: '#3D405B',
    borderRadius: 5,
  },
  silabaText: {
    color: '#fff',
    fontSize: 25,
  },
});

export default Silabas;