import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';

const Start = ({ navigation }) => {
  return (
    <View style={style.image}>
      <TouchableOpacity onPress={() => navigation.navigate('HomeList')}>
        <Image source={require('../assets/logoAprenderMais.png')} style={ style.headerImage} />
        <Text style={{ textAlign: 'center', fontSize: 20, height: 50 }}>
          Dentro e fora da escola.
        </Text>
        <Image source={require('../assets/book.png')} style={ style.book} />
      </TouchableOpacity>
    </View>
  );
};

const style = StyleSheet.create({
  image: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
    headerImage: {
    width: 300,
    height: 150,
    alignSelf: 'center',
    marginBottom: 30,
    padding: 50,
  },
    book: {
    width: 200,
    height: 150,
    alignSelf: 'center',
    marginBottom: 30,
    padding: 50,
  },
  
});

export default Start;
