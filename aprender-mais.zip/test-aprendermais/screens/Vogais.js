import React from 'react';
import {
  Button,
  View,
  Text,
  FlatList,
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { Audio } from 'expo-av';

function VirtualizedListPage({ navigation }) {
  const DATA = Array.from({ length: 1000 }, (_, i) => `Item ${i + 1}`);

  const renderItem = ({ item }) => (
    <View style={styles.item}>
      <Text>{item}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
      />
    </SafeAreaView>
  );
}

function Vogais({ navigation }) {
  const vowels = [
    { label: 'A', sound: require('../assets/alfabeto/a.mp3'), cor: '#ff3131' },
    { label: 'E', sound: require('../assets/alfabeto/e.mp3'), cor: '#8c52ff' },
    { label: 'I', sound: require('../assets/alfabeto/i.mp3'), cor: '#5ce1e6' },
    { label: 'O', sound: require('../assets/alfabeto/o.mp3'), cor: '#c1ff72' },
    { label: 'U', sound: require('../assets/alfabeto/u.mp3'), cor: '#0097b2' },
  ];

 const playSound = async (sound) => {
    const { sound: playbackObject } = await Audio.Sound.createAsync(sound);
    await playbackObject.playAsync();
  };

  return (
      <View style={styles.container}>
        <View style={styles.gridContainer}>
          {vowels.map((vowel, index) => (
            <View key={vowel.label} style={styles.gridItem}>
              <TouchableOpacity
                onPress={() => playSound(vowel.sound)}
                style={[styles.item, { backgroundColor: vowel.cor }]}>
                <Text style={styles.text}>{vowel.label}</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  gridItem: {
    margin: 10,
    height: 65,
    width: 65,
  },
  item: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 5,
    margin: 5,
    borderRadius: 10,
    backgroundColor: '#3D405B',
  },
  text: {
    fontFamily: 'mrt-lili',
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 35,
    lineHeight: 35,
  },
});

export default Vogais;


